document.getElementById('shareLocation').addEventListener('click', () => {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const latitude = position.coords.latitude;
                const longitude = position.coords.longitude;
                alert(`Your location: Latitude ${latitude}, Longitude ${longitude}`);
                // Send location to server or display on a map
            },
            (error) => {
                alert('Unable to retrieve location: ' + error.message);
            }
        );
    } else {
        alert('Geolocation is not supported by your browser.');
    }
});
